You need to add the Android platform and install the plugin before running the example:

```
cordova platform add android
cordova plugin add https://github.com/mesmotronic/cordova-plugin-fullscreen.git
cordova run android
```
